<html>
<head>
    <title>Selamat Datang Member</title>
    <link rel="stylesheet" href="style1.css" type="text/css">
</head>
<body>
    <br>
    <center><h1>Selamat Datang Member</h1>
    Silahkan logout dengan klik link <a href="logout.php" class="link">Disini</a></center>
</body>
</html>